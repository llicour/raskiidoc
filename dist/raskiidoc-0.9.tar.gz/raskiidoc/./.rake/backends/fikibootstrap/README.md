fikiboostrap
============

Asciidoc Backend using Twitter Bootstrap stylesheet

Installation
---
To install you can download project sources in zip format (directly from
github):

```bash
wget https://github.com/mmornati/fikiboostrap/archive/master.zip -O fikibootstrap.zip
```

then, using asciidoc, you can install the fikibootstrap backend:

```bash
asciidoc --backend install fikibootstrap.zip
```

